// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';

import 'package:bordered_text/bordered_text.dart';

import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

enum _Element {
  background,
  text,
  shadow,
  textShaddowtwo,
}

final _lightTheme = {
  _Element.background: Color(0xFF70B8C2), // blue "teal"
  _Element.text: Colors.white, //white
  _Element.shadow: Color(0xFFE62CAB), // pink
  _Element.textShaddowtwo: Colors.black,
};

final _darkTheme = {
  _Element.background: Color(0xFF0c3347), // dark blue
  _Element.text: Color(0xFFE62CAB), //pink
  _Element.shadow: Colors.blue[900],
  _Element.textShaddowtwo: Colors.white,
};

class DigitalClock extends StatefulWidget {
  const DigitalClock(this.model);

  final ClockModel model;

  @override
  _DigitalClockState createState() => _DigitalClockState();
}

class _DigitalClockState extends State<DigitalClock>
    with SingleTickerProviderStateMixin {
  Animation<double> animation;
  AnimationController controller;
  DateTime _dateTime = DateTime.now();
  Timer _timer;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    _updateTime();
    _updateModel();
    super.initState();
  }

  @override
  void didUpdateWidget(DigitalClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    widget.model.dispose();
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      // Cause the clock to rebuild when the model changes.
    });
  }

  void _updateTime() {
    setState(() {
      _dateTime = _dateTime.add(Duration(minutes: 1));
      _timer = Timer(
        Duration(seconds: 3),
        _updateTime,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).brightness == Brightness.light
        ? _lightTheme
        : _darkTheme;

    // date info
    final hour =
        DateFormat(widget.model.is24HourFormat ? 'HH' : 'hh').format(_dateTime);
    final hourOnes = hour[0];
    final hourTens = hour[1];
    final minute = DateFormat('mm').format(_dateTime);
    final minutesOnes = minute[0];
    final minutesTens = minute[0];
    final day = DateFormat.EEEE().format(_dateTime);
    final fontSize = MediaQuery.of(context).size.width / 5;
    final is24HrFormat = !widget.model.is24HourFormat;
    final amPm =DateFormat('a').format(_dateTime); 

    //style info

    TextStyle clockTextTheme = TextStyle(
        color: colors[_Element.text],
        fontFamily: 'Odachi',
        height: 1.25,
        fontSize: fontSize / 1.3,
        letterSpacing: 40,
        shadows: [
          Shadow(
            blurRadius: 3,
            offset: Offset(6, 3),
            color: colors[_Element.shadow],
          ),
          BoxShadow(
              offset: Offset(3, 1.5), color: colors[_Element.textShaddowtwo]),
        ]);
    TextStyle colonStyle = TextStyle(
        fontFamily: 'Raleway',
        color: colors[_Element.textShaddowtwo],
        fontSize: fontSize,
        fontWeight: FontWeight.bold,
        shadows: [
          Shadow(offset: Offset(-1, -1), color: colors[_Element.text]),
          Shadow(offset: Offset(-1, 1), color: colors[_Element.text]),
          Shadow(offset: Offset(1, 1), color: colors[_Element.text]),
          Shadow(offset: Offset(1, -1), color: colors[_Element.text]),
        ]);

    TextStyle numbersStyle = (colonStyle).copyWith(
        letterSpacing: 15.0,
        color: colors[_Element.text],
        height: 1.25,
        shadows: [
          Shadow(offset: Offset(-13, 0), color: colors[_Element.text]),
          Shadow(offset: Offset(-8, 0), color: colors[_Element.textShaddowtwo]),
          Shadow(offset: Offset(-5, 0), color: colors[_Element.shadow]),
        ]);

    return Container(
      color: colors[_Element.background],

      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          FittedBox(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    DigitWidget(hourOnes, numbersStyle),
                    DigitWidget(hourTens, numbersStyle),
                    Container(
                        width: MediaQuery.of(context).size.width / 5,
                        child: Center(
                            child: Text(
                          ':',
                          style: colonStyle,
                        ))),
                    DigitWidget(minutesOnes, numbersStyle),
                    DigitWidget(minutesTens, numbersStyle),
                  ],
                ),
                Visibility(
                  visible: is24HrFormat,
                                  child: Container(
                      decoration: BoxDecoration(
                          color: colors[_Element.textShaddowtwo],
                          border: Border.all(color: colors[_Element.text])),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 2.0, horizontal: 4.0),
                        child: Text(
                          amPm,
                          style: TextStyle(
                              color: colors[_Element.text],
                              fontSize: fontSize / 5,
                              fontWeight: FontWeight.bold),
                        ),
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.all(17.0),
                  child: BorderedText(
                    strokeWidth: 3,
                    strokeColor: colors[_Element.textShaddowtwo],
                    child: Text(
                      day,
                      style: clockTextTheme,
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class DigitWidget extends StatelessWidget {
  DigitWidget(this.hour, this.numbersStyle);

  final String hour;
  final TextStyle numbersStyle;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: MediaQuery.of(context).size.width / 5,
        child: Center(
            child: Text(
          hour[0],
          style: numbersStyle,
        )));
  }
}
