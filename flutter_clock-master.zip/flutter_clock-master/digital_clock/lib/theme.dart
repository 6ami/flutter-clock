import 'package:flutter/material.dart';

 class BaseThemeSTYLE {
        //  static Map<String, Color> _themeColors =  _darkTheme;
// this.colors[_Element.shadow]
//   BaseTheme( {this._Element}){
//       // _themeColors = (brightness == Brightness.dark) ? _darkTheme : _lightTheme;

//   }
  //  Brightness brightness;

  // context;
  // final fontSize = MediaQuery.of(context).size.width / 5;


    // TextStyle clockTextTheme = TextStyle(
    //   color: Colors.white,
    //   fontFamily: 'Pacifico',
    //   height: 1.25,
    //   fontSize: 90,
    //   // letterSpacing: 20,
    //   shadows: [
    //     Shadow(
    //       // spreadRadius: 3,
    //       // bottomRight
    //       blurRadius: 3,
    //       offset: Offset(9, 4.5),
    //       color: Colors.black,
    //     ),
    //     BoxShadow(
    //         // spreadRadius: 3,
    //         // bottomRight
    //         offset: Offset(3, 1.5),
    //         color: Colors.pink),
    //   ]);

    // TextStyle numbersStyle = TextStyle(
    //   letterSpacing: 15.0,
    //   color:  _themeColors['text'],
    //   fontFamily: 'Raleway',
    //   height: 1.25,
    //   fontSize: 162,
    //   shadows: [
    //     BoxShadow(
    //         // spreadRadius: 30,
    //         // bottomRight
    //         offset: Offset(-13, 0),
    //         color: Color(0xFFD0E0E5)),
    //     BoxShadow(
    //         // bottomRight
    //         offset: Offset(-10, 0),
    //         color: Colors.black),
    //     BoxShadow(
    //         // bottomRight
    //         offset: Offset(-5, 0),
    //         color: _themeColors['textShadowOne']),
    //     BoxShadow(
    //         // bottomRight
    //         offset: Offset(-2, 0),
    //         color: Colors.black),
    //   ]);
       

}
final Map<String, Color> _lightTheme = {
  'background': Color(0xFF70B8C2),
  'text': Color(0xFFFFFFFF),
  'numberShadowOne': Color(0xFFE62CAB),
  'numberShadowTwo': Color(0xFFFF9707),
  'textShadowOne': Color(0xFFE62CAB),
  'textShaddowtwo': Color(0xFFF1D41E),
  'textShaddowthree': Color(0xFFE8E3DC),
  'textShaddowFour': Color(0xFFEC6F05)
};

final Map<String, Color> _darkTheme = {
  'background': Color(0xFF0c3347),
  'text': Color(0xFF24B694),
  'numberShadowOne ': Color(0xFF174EA6),
  'numberShadowTwo': Colors.grey[300],
  'textShadowOne': Color(0xFFffffff)
};


