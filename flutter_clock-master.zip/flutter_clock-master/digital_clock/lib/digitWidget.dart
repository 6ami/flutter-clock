import 'package:flutter/material.dart';

class DigitWidget extends StatelessWidget {
  DigitWidget(this.hour, this.numbersStyle);

  final String hour;
  final TextStyle numbersStyle;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: MediaQuery.of(context).size.width / 5,
        child: Center(
            child: Text(
          hour[0],
          style: numbersStyle,
        )));
  }
}
